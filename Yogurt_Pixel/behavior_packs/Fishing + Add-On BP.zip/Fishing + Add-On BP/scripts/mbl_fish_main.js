import { world, system, WorldAfterEvents } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

//============ Code to retrive details for everything to work :) =====================================================================================

function getPlayer() {
  const allPlayers = world.getAllPlayers();
  if (allPlayers.length === 0) {
    return undefined;
  }

  return allPlayers[0];
}

function getPlayerDimension() {
  const player = getPlayer();
  if (player === undefined) {
    return undefined;
  }
  return player.dimension;
}

function getPlayerLocation() {
  const player = getPlayer();
  if (player === undefined) {
    return undefined;
  }
  return player.location;
}


//============ Code to give starter book when player enters for first time =====================================================================================

world.afterEvents.playerSpawn.subscribe((event) => {

	const player = event.player; // Player 
    const playerDimension = getPlayerDimension();
    const playerLocation = getPlayerLocation();

    if(player.getDynamicProperty("mbl_oldPlayer") === undefined) {
    //  console.warn(`${player.name} joined for the first time, book.`); 
      playerDimension.spawnEntity("mbl_fish:exp_book_fish", playerLocation); //change to starter book when ready
      player.setDynamicProperty("mbl_oldPlayer", "true");
  };
}); 



//============ Code to setupp all the scoreboards =====================================================================================

world.afterEvents.playerSpawn.subscribe(() => {
  const mbl_fish_scoreboard = world.scoreboard.getObjective("mbl_fish_settings"); // scoreboard turning on and of advanced fishing
  if(mbl_fish_scoreboard?.getScore("fishing") === 0){ return  };
  if(mbl_fish_scoreboard?.getScore("fishing") === 1){ return  };
  world.scoreboard.addObjective("mbl_fish_settings", "FISHING SETTINGS");
});
world.afterEvents.playerSpawn.subscribe((fishTotal) => {
  const player = fishTotal.player; // Player 
  const mbl_fish_total_scoreboard = world.scoreboard.getObjective("mbl_total_fish"); // scoreboard total fish collection
  mbl_fish_total_scoreboard?.addScore(player, 0);
  if(mbl_fish_total_scoreboard?.getScore(player) >= 0){ return  };
  world.scoreboard.addObjective("mbl_total_fish", "TOTAL COLLECTION");
});
world.afterEvents.playerSpawn.subscribe((fishTotalC) => {
  const player = fishTotalC.player; // Player 
  const mbl_fish_totalC_scoreboard = world.scoreboard.getObjective("mbl_total_fishc"); // scoreboard common fish collection
  mbl_fish_totalC_scoreboard?.addScore(player, 0);
  if(mbl_fish_totalC_scoreboard?.getScore(player) >= 0){ return  };
  world.scoreboard.addObjective("mbl_total_fishc", "TOTAL COMMON");
});
world.afterEvents.playerSpawn.subscribe((fishTotalUC) => {
  const player = fishTotalUC.player; // Player 
  const mbl_fish_totalUC_scoreboard = world.scoreboard.getObjective("mbl_total_fishu"); // scoreboard uncommon fish collection
  mbl_fish_totalUC_scoreboard?.addScore(player, 0);
  if(mbl_fish_totalUC_scoreboard?.getScore(player) >= 0){ return  };
  world.scoreboard.addObjective("mbl_total_fishu", "TOTAL UNCOMMON");
});
world.afterEvents.playerSpawn.subscribe((fishTotalR) => {
  const player = fishTotalR.player; // Player 
  const mbl_fish_totalR_scoreboard = world.scoreboard.getObjective("mbl_total_fishr"); // scoreboard common fish collection
  mbl_fish_totalR_scoreboard?.addScore(player, 0);
  if(mbl_fish_totalR_scoreboard?.getScore(player) >= 0){ return  };
  world.scoreboard.addObjective("mbl_total_fishr", "TOTAL RARE");
});

world.afterEvents.playerSpawn.subscribe((score) => {
  const player = score.player; // Player 
  const mbl_fish_scoreboard = world.scoreboard.getObjective("mbl_fish_settings"); // scoreboard
  const mbl_fish_total_scoreboard = world.scoreboard.getObjective("mbl_total_fish"); // scoreboard
  const mbl_fish_totalC_scoreboard = world.scoreboard.getObjective("mbl_total_fishc"); // scoreboard
  const mbl_fish_totalUC_scoreboard = world.scoreboard.getObjective("mbl_total_fishu"); // scoreboard
  const mbl_fish_totalR_scoreboard = world.scoreboard.getObjective("mbl_total_fishr"); // scoreboard
  mbl_fish_scoreboard?.addScore("fishing", 0);
  mbl_fish_total_scoreboard?.addScore(player, 0);
  mbl_fish_totalC_scoreboard?.addScore(player, 0);
  mbl_fish_totalUC_scoreboard?.addScore(player, 0);
  mbl_fish_totalR_scoreboard?.addScore(player, 0);
});


//============ Code to catch new fish =====================================================================================

// Subscribe to the entityRemove event to detect when the fishing hook is removed


// Function to handle the entity removal event (fishing hook removal)
function handleItemUse(entityDeathEvent) {
  const entity = entityDeathEvent.typeId;

  if (entity === "minecraft:fishing_hook" && world.getDynamicProperty("fishingEnabled") === true) {
      // Subscribe to entitySpawn event to handle the next spawned item
    //  console.warn(`Hook removed.`);
      world.afterEvents.entitySpawn.subscribe(entityHitHandler);
  }
}

// Function to handle entity spawn events
function entityHitHandler(entitySpawnEvent) {
  const entity = entitySpawnEvent.entity;

  // Check if the spawned entity is an item and if the world dynamic property "fishingEnabled" is true
  if (entity.typeId === "minecraft:item" && world.getDynamicProperty("fishingEnabled") === true) {

        world.getDimension("overworld").runCommand("function mobblocks/fish/mbl_fish_catC");
        world.getDimension("overworld").runCommand("function mobblocks/fish/mbl_fish_catUC");
        world.getDimension("overworld").runCommand("function mobblocks/fish/mbl_fish_catR");
     //   console.warn(`Backup ran.`);
        world.afterEvents.entitySpawn.unsubscribe(entityHitHandler); // Unsubscribe from the entitySpawn 
  }
}

// Subscribe to the entity remove event
world.afterEvents.entityRemove.subscribe(handleItemUse);

// Assuming the dynamic property "fishingEnabled" is already set somewhere in your script or world setup

// Helper function to get score
const getScore = (objective, target, useZero = true) => {
  try {
    const obj = world.scoreboard.getObjective(objective);
    if (typeof target == 'string') {
      return obj.getScore(obj.getParticipants().find(v => v.displayName == target));
    }
    return obj.getScore(target.scoreboard);
  } catch {
    return useZero ? 0 : NaN;
  }
};

// Fish data
const fishData = [
    { id: "mbl_fish:alligator_gar", name: "Alligator Gar", type: "Rare", cookable: "Yes", found: "Fresh Water", details: "Known for their long, needle-like snouts and prehistoric appearance.", image:"textures/mobblocks/fish/items/alligator_gar" },
    { id: "mbl_fish:anchovy", name: "Anchovy", type: "Common", cookable: "Yes", found: "Salt Water", details: "Often used in fish sauces and as bait fish.", image:"textures/mobblocks/fish/items/anchovy" },
    { id: "mbl_fish:arctic_char", name: "Arctic Char", type: "Uncommon", cookable: "Yes", found: "Fresh Water", details: "Can survive in cold, deep waters and are often found in the Arctic.", image:"textures/mobblocks/fish/items/arctic_char" },
    { id: "mbl_fish:barracuda", name: "Barracuda", type: "Uncommon", cookable: "Yes", found: "Sea Water", details: "Known for their fearsome appearance and speed.", image:"textures/mobblocks/fish/items/barracuda" },
    { id: "mbl_fish:barramundi", name: "Barramundi", type: "Uncommon", cookable: "Yes", found: "Sea Water", details: "Known as Asian sea bass and popular in Australian cuisine.", image:"textures/mobblocks/fish/items/barramundi" },
    { id: "mbl_fish:black_crappie", name: "Black Crappie", type: "Uncommon", cookable: "Yes", found: "Fresh Water", details: "Native to North America, they put up a spirited fight when hooked.", image:"textures/mobblocks/fish/items/black_crappie" },
    { id: "mbl_fish:blue_marlin", name: "Blue Marlin", type: "Rare", cookable: "Yes", found: "Salt Water", details: "Can grow up to 5 metres long and are prized in sport fishing", image:"textures/mobblocks/fish/items/blue_marlin" },
    { id: "mbl_fish:bluefin_tuna", name: "Bluefin Tuna", type: "Rare", cookable: "Yes", found: "Salt Water", details: "Highly prized in sushi, leading to severe overfishing concerns.", image:"textures/mobblocks/fish/items/bluefin_tuna" },
    { id: "mbl_fish:bluegill", name: "Bluegill", type: "Common", cookable: "Yes", found: "Fresh Water", details: "Recognized for its colorful, deep-bodied appearance.", image:"textures/mobblocks/fish/items/bluegill" },
    { id: "mbl_fish:bowfin", name: "Bowfin", type: "Rare", cookable: "Yes", found: "Fresh Water", details: "An ancient fish species found in swamps and marshes.", image:"textures/mobblocks/fish/items/bowfin" },
    { id: "mbl_fish:bream", name: "Bream", type: "Uncommon", cookable: "Yes", found: "Fresh Water", details: "Found in many rivers and lakes in Europe.", image:"textures/mobblocks/fish/items/bream" },
    { id: "mbl_fish:brown_trout", name: "Brown Trout", type: "Common", cookable: "Yes", found: "Fresh Water", details: "Known for being territorial and wary, they can be difficult to catch.", image:"textures/mobblocks/fish/items/brown_trout" },
    { id: "mbl_fish:burbot", name: "Burbot", type: "Common", cookable: "Yes", found: "Fresh Water", details: "A member of the cod family that has adapted to freshwater living.", image:"textures/mobblocks/fish/items/burbot" },
    { id: "mbl_fish:channel_catfish", name: "Channel Catfish", type: "Common", cookable: "Yes", found: "Fresh Water", details: "A large species of North American freshwater fish found in rivers, lakes, and ponds.", image:"textures/mobblocks/fish/items/channel_catfish" },
    { id: "mbl_fish:chub", name: "Chub", type: "Common", cookable: "Yes", found: "Fresh Water", details: "European chub are omnivores, eating everything from smaller fish to plant life. ", image:"textures/mobblocks/fish/items/chub" },
    { id: "minecraft:tropical_fish", name: "Clown Fish", type: "Rare", cookable: "No", found: "Salt Water", details: "These fish start their lives as males, but as they grow older and eventually become female.", image:"textures/items/fish_clownfish_raw" },
    { id: "mbl_fish:cobia", name: "Cobia", type: "Rare", cookable: "Yes", found: "Salt Water", details: "Known for their rapid growth and firm texture.", image:"textures/mobblocks/fish/items/cobia" },
    { id: "minecraft:cod", name: "Cod", type: "Common", cookable: "Yes", found: "Salt Water", details: "A nutritious and flavorful fish loaded with lean protein, vitamins, and minerals.", image:"textures/items/fish_raw" },
    { id: "mbl_fish:coelacanth", name: "Coelacanth", type: "Rare", cookable: "Yes", found: "Salt Water", details: "Once thought extinct, it is a living fossil from the dinosaur age.", image:"textures/mobblocks/fish/items/coelacanth" },
    { id: "mbl_fish:common_carp", name: "Common Carp", type: "Common", cookable: "Yes", found: "Fresh Water", details: "One of the most widely distributed freshwater fish species.", image:"textures/mobblocks/fish/items/common_carp" },
    { id: "mbl_fish:common_molly", name: "Common Molly", type: "Common", cookable: "No", found: "Fresh Water", details: "Mollies are native to the warm, slow-moving or still waters of Central America.", image:"textures/mobblocks/fish/items/common_molly" },
    { id: "mbl_fish:croaker", name: "Croaker", type: "Uncommon", cookable: "Yes", found: "Salt Water", details: "Named for the croaking sound they make by vibrating their swim bladders.", image:"textures/mobblocks/fish/items/croaker" },
    { id: "mbl_fish:crucian_carp", name: "Crucian Carp", type: "Common", cookable: "Yes", found: "Fresh Water", details: "These fish have an ability to tolerate low oxygen levels and variations in water quality.", image:"textures/mobblocks/fish/items/crucian_carp" },
    { id: "mbl_fish:mahi_mahi", name: "Dolphin Fish (Mahi-Mahi)", type: "Common", cookable: "Yes", found: "Salt Water", details: "Not related to dolphins; known for their vibrant colors.", image:"textures/mobblocks/fish/items/mahi_mahi" },
    { id: "mbl_fish:eel", name: "Eel", type: "Uncommon", cookable: "Yes", found: "Fresh Water", details: "Known for their long, snake-like bodies and smooth, scaleless skin.", image:"textures/mobblocks/fish/items/eel" },
    { id: "mbl_fish:escolar", name: "Escolar", type: "Uncommon", cookable: "Yes", found: "Salt Water", details: "Known for their high oil content, which can cause digestive issues if eaten in large amounts.", image:"textures/mobblocks/fish/items/escolar" },
    { id: "mbl_fish:goby", name: "Goby", type: "Common", cookable: "Yes", found: "Salt Water", details: "A small fish often found in tidepools and rocky shores.", image:"textures/mobblocks/fish/items/goby" },
    { id: "mbl_fish:goldfish", name: "Goldfish", type: "Common", cookable: "No", found: "Fresh Water", details: "Domesticated from wild carp, known for their variety of colors.", image:"textures/mobblocks/fish/items/goldfish" },
    { id: "mbl_fish:grass_carp", name: "Grass Carp", type: "Uncommon", cookable: "Yes", found: "Fresh Water", details: "Consume over three times their body weight in vegetation each day.", image:"textures/mobblocks/fish/items/grass_carp" },
    { id: "mbl_fish:grayling", name: "Grayling", type: "Common", cookable: "Yes", found: "Fresh Water", details: "Related to salmon, they are distinguished by their large, sail-like dorsal fins.", image:"textures/mobblocks/fish/items/grayling" },
    { id: "mbl_fish:grouper", name: "Grouper", type: "Uncommon", cookable: "Yes", found: "Salt Water", details: "Known for their large mouths and slow movements.", image:"textures/mobblocks/fish/items/grouper" },
    { id: "mbl_fish:gudgeon", name: "Gudgeon", type: "Common", cookable: "No", found: "Fresh Water", details: "Commonly found in rivers and lakes across Europe and parts of Asia.", image:"textures/mobblocks/fish/items/gudgeon" },
    { id: "mbl_fish:guppy", name: "Guppy", type: "Common", cookable: "No", found: "Fresh Water", details: "Popular aquarium fish, known for their bright colors.", image:"textures/mobblocks/fish/items/guppy" },
    { id: "mbl_fish:haddock", name: "Haddock", type: "Common", cookable: "Yes", found: "Salt Water", details: "A staple in British fish and chips.", image:"textures/mobblocks/fish/items/haddock" },
    { id: "mbl_fish:halibut", name: "Halibut", type: "Uncommon", cookable: "Yes", found: "Salt Water", details: "One of the largest flatfish species.", image:"textures/mobblocks/fish/items/halibut" },
    { id: "mbl_fish:herring", name: "Herring", type: "Common", cookable: "Yes", found: "Salt Water", details: "One of the most abundant fish species, crucial in various ecosystems.", image:"textures/mobblocks/fish/items/herring" },
    { id: "mbl_fish:large_mouth_bass", name: "Largemouth Bass", type: "Common", cookable: "Yes", found: "Fresh Water", details: "Popular sport fish known for their aggressive behaviour.", image:"textures/mobblocks/fish/items/large_mouth_bass" },
    { id: "mbl_fish:lingcod", name: "Lingcod", type: "Common", cookable: "Yes", found: "Salt Water", details: "Not a true cod, known for their fierce predatory behaviour.", image:"textures/mobblocks/fish/items/lingcod" },
    { id: "mbl_fish:lionfish", name: "Lionfish", type: "Uncommon", cookable: "No", found: "Salt Water", details: "Venomous spines and invasive in many parts of the world.", image:"textures/mobblocks/fish/items/lionfish" },
    { id: "mbl_fish:mackerel", name: "Mackerel", type: "Common", cookable: "Yes", found: "Salt Water", details: "Known for their fast swimming and oily flesh.", image:"textures/mobblocks/fish/items/mackerel" },
    { id: "mbl_fish:milkfish", name: "Milkfish", type: "Common", cookable: "Yes", found: "Salt Water", details: "Cultured extensively in Southeast Asia, especially the Philippines.", image:"textures/mobblocks/fish/items/milkfish" },
    { id: "mbl_fish:minnow", name: "Minnow", type: "Common", cookable: "No", found: "Fresh Water", details: "A small sized, that is used as bait fish in sport fishing.", image:"textures/mobblocks/fish/items/minnow" },
    { id: "mbl_fish:monkfish", name: "Monkfish", type: "Uncommon", cookable: "Yes", found: "Salt Water", details: "Known for their large heads and wide mouths; sometimes called (poor man's lobster).", image:"textures/mobblocks/fish/items/monkfish" },
    { id: "mbl_fish:nile_perch", name: "Nile Perch", type: "Uncommon", cookable: "Yes", found: "Fresh Water", details: "A top predator in African lakes, introduced to many non-native areas.", image:"textures/mobblocks/fish/items/nile_perch" },
    { id: "mbl_fish:northern_pike", name: "Northern Pike", type: "Common", cookable: "Yes", found: "Fresh Water", details: "Known for their elongated bodies and sharp teeth.", image:"textures/mobblocks/fish/items/northern_pike" },
    { id: "mbl_fish:opah", name: "Opah", type: "Rare", cookable: "Yes", found: "Salt Water", details: "Known for their unique body shape and ability to generate heat to stay warm in cold water.", image:"textures/mobblocks/fish/items/opah" },
    { id: "mbl_fish:oscar", name: "Oscar", type: "Uncommon", cookable: "Yes", found: "Fresh Water", details: "Originating from the Amazon Basin, oscars are beloved pet fish.", image:"textures/mobblocks/fish/items/oscar" },
    { id: "mbl_fish:patagonian_toothfish", name: "Patagonian Toothfish", type: "Rare", cookable: "Yes", found: "Salt Water", details: "Also known as Chilean sea bass, valued for its rich flavour.", image:"textures/mobblocks/fish/items/patagonian_toothfish" },
    { id: "mbl_fish:perch", name: "Perch", type: "Common", cookable: "Yes", found: "Fresh Water", details: "Found in many freshwater bodies and known for their mild flavour.", image:"textures/mobblocks/fish/items/perch" },
    { id: "mbl_fish:piranha", name: "Piranha", type: "Uncommon", cookable: "Yes", found: "Fresh Water", details: "Known for their sharp teeth and feeding frenzies.", image:"textures/mobblocks/fish/items/piranha" },
    { id: "mbl_fish:pollock", name: "Pollock", type: "Common", cookable: "Yes", found: "Salt Water", details: "Commonly used in fish sticks and imitation crab meat.", image:"textures/mobblocks/fish/items/pollock" },
    { id: "mbl_fish:pompano", name: "Pompano", type: "Uncommon", cookable: "Yes", found: "Salt Water", details: "Known for their flat, rounded bodies and delicious taste.", image:"textures/mobblocks/fish/items/pompano" },
    { id: "minecraft:pufferfish", name: "Pufferfish", type: "Uncommon", cookable: "No", found: "Salt Water", details: "Can inflate to evade predators, and is very dangerous to eat because they contain a deadly poison.", image:"textures/items/fish_pufferfish_raw" },
    { id: "mbl_fish:pumkinseed", name: "Pumkinseed", type: "Uncommon", cookable: "Yes", found: "Fresh Water", details: "Known for their stunning, colorful appearance.", image:"textures/mobblocks/fish/items/pumkinseed" },
    { id: "mbl_fish:rainbow_trout", name: "Rainbow Trout", type: "Common", cookable: "Yes", found: "Fresh Water", details: "Known for their vibrant colors and popular in recreational fishing.", image:"textures/mobblocks/fish/items/rainbow_trout" },
    { id: "mbl_fish:red_drum", name: "Red Drum", type: "Uncommon", cookable: "Yes", found: "Salt Water", details: "Also known as redfish, popular among anglers for their fight and flavour.", image:"textures/mobblocks/fish/items/red_drum" },
    { id: "mbl_fish:red_snapper", name: "Red Snapper", type: "Uncommon", cookable: "Yes", found: "Salt Water", details: "Popular for their firm texture and delicate flavour.", image:"textures/mobblocks/fish/items/red_snapper" },
    { id: "mbl_fish:roach", name: "Roach", type: "Common", cookable: "Yes", found: "Fresh Water", details: "Related to carps, these fish travel in large groups.", image:"textures/mobblocks/fish/items/roach" },
    { id: "mbl_fish:roosterfish", name: "Roosterfish", type: "Uncommon", cookable: "Yes", found: "Salt Water", details: "Known for their distinctive dorsal fin and game fish status.", image:"textures/mobblocks/fish/items/roosterfish" },
    { id: "mbl_fish:rudd", name: "Rudd", type: "Common", cookable: "Yes", found: "Fresh Water", details: "Known for a green to silver body with bright red or orange fins.", image:"textures/mobblocks/fish/items/rudd" },
    { id: "mbl_fish:sailfish", name: "Sailfish", type: "Uncommon", cookable: "Yes", found: "Salt Water", details: "Known for their impressive speed and long, bill-like upper jaws.", image:"textures/mobblocks/fish/items/sailfish" },
    { id: "minecraft:salmon", name: "Salmon", type: "Common", cookable: "Yes", found: "Fresh Water", details: "Salmon are an important food delicacy in many parts of the world.", image:"textures/items/fish_salmon_raw" },
    { id: "mbl_fish:sardine", name: "Sardine", type: "Common", cookable: "Yes", found: "Salt Water", details: "A small, oily fish often canned or smoked.", image:"textures/mobblocks/fish/items/sardine" },
    { id: "mbl_fish:sea_bass", name: "Sea Bass", type: "Common", cookable: "Yes", found: "Salt Water", details: "Known for their mild flavour and found in both freshwater and marine environments.", image:"textures/mobblocks/fish/items/sea_bass" },
    { id: "mbl_fish:skipjack_tuna", name: "Skipjack Tuna", type: "Common", cookable: "Yes", found: "Salt Water", details: "A major source of canned tuna worldwide.", image:"textures/mobblocks/fish/items/skipjack_tuna" },
    { id: "mbl_fish:snapper", name: "Snapper", type: "Uncommon", cookable: "Yes", found: "Salt Water", details: "Includes many species, popular in both sport fishing and commercial fisheries.", image:"textures/mobblocks/fish/items/snapper" },
    { id: "mbl_fish:stickleback", name: "Stickleback", type: "Common", cookable: "No", found: "Fresh Water", details: "Small spiny fish that become highly aggressive and defend their nests against intruders.", image:"textures/mobblocks/fish/items/stickleback" },
    { id: "mbl_fish:striped_bass", name: "Striped Bass", type: "Uncommon", cookable: "Yes", found: "Salt Water", details: "Popular both in freshwater and saltwater, known for their fighting ability.", image:"textures/mobblocks/fish/items/striped_bass" },
    { id: "mbl_fish:sturgeon", name: "Sturgeon", type: "Rare", cookable: "Yes", found: "Fresh Water", details: "Known for their longevity, with some species living for over 100 years.", image:"textures/mobblocks/fish/items/sturgeon" },
    { id: "mbl_fish:swordfish", name: "Swordfish", type: "Rare", cookable: "Yes", found: "Salt Water", details: "Named for their long, flat bills and are highly migratory.", image:"textures/mobblocks/fish/items/swordfish" },
    { id: "mbl_fish:tarpon", name: "Tarpon", type: "Uncommon", cookable: "Yes", found: "Salt Water", details: "Can grow up to 2.5 metres and are known for their acrobatic jumps when hooked.", image:"textures/mobblocks/fish/items/tarpon" },
    { id: "mbl_fish:tench", name: "Tench", type: "Common", cookable: "Yes", found: "Fresh Water", details: "Known as the doctor fish, as it was once thought to possess healing abilities.", image:"textures/mobblocks/fish/items/tench" },
    { id: "mbl_fish:tilapia", name: "Tilapia", type: "Common", cookable: "Yes", found: "Fresh Water", details: "Commonly farmed fish, adaptable to various environments.", image:"textures/mobblocks/fish/items/tilapia" },
    { id: "mbl_fish:tilefish", name: "Tilefish", type: "Rare", cookable: "Yes", found: "Salt Water", details: "Known for their colorful scales and burrowing habits.", image:"textures/mobblocks/fish/items/tilefish" },
    { id: "mbl_fish:wahoo", name: "Wahoo", type: "Uncommon", cookable: "Yes", found: "Salt Water", details: "Known for their speed and excellent taste.", image:"textures/mobblocks/fish/items/wahoo" },
    { id: "mbl_fish:walleye", name: "Walleye", type: "Common", cookable: "Yes", found: "Fresh Water", details: "Popular game fish known for their large, glassy eyes.", image:"textures/mobblocks/fish/items/walleye" },
    { id: "mbl_fish:white_bass", name: "White Bass", type: "Common", cookable: "Yes", found: "Fresh Water", details: "A medium-sized fish that can be found in the Great Lakes region.", image:"textures/mobblocks/fish/items/white_bass" },
    { id: "mbl_fish:whitefish", name: "Whitefish", type: "Uncommon", cookable: "Yes", found: "Fresh Water", details: "Found in cold freshwater bodies, valued for their mild flavour.", image:"textures/mobblocks/fish/items/whitefish" },
    { id: "mbl_fish:yellowfin_tuna", name: "Yellowfin Tuna", type: "Uncommon", cookable: "Yes", found: "Salt Water", details: "Known for their bright yellow fins and large size.", image:"textures/mobblocks/fish/items/yellowfin_tuna" },
    { id: "mbl_fish:zander", name: "Zander", type: "Uncommon", cookable: "Yes", found: "Fresh Water", details: "Also known as pikeperch, popular in European cuisine.", image:"textures/mobblocks/fish/items/zander" },
  
  // Add the rest of the fish data here
];

// Titles and messages
const titles = {
  off: "§l§d高级钓鱼模式已打开",
  on: "§l§d高级钓鱼模式已关闭",
  collection: "§l§d我的收集",
  common: "§l§d普通品质",
  uncommon: "§l§d上品品质",
  rare: "§l§d稀有品种"
};

// Helper functions for dynamic properties
const getDynamicProperty = (player, property) => player.getDynamicProperty(property);

// Helper function to create fish info forms
const createFishForm = (title, cookable, found, details) => {
  const form = new ActionFormData().title(title).body(`\n§5In game information!\n§r\n§aCookable: §r${cookable}\n§aFound in: §r${found}\n\n§bExtra Info\n§r${details}\n\n`).button(`§e返回`, "textures/mobblocks/fish/items/custom_fish_0");
  return form;
};

// Handling item use event
world.beforeEvents.itemUse.subscribe(data => {
  const player = data.source;

  // Check if the used item is the settings fish item
  if (data.itemStack.typeId === "mbl_fish:settings_fish") {
    const scoreboard = world.scoreboard.getObjective("mbl_fish_settings");
    const fishingStatus = scoreboard?.getScore("fishing") ?? 0;
    system.run(() => fishingStatus === 0 ? mainOn(player) : mainOff(player));
  }

  // Function to show main form when Advanced Fishing is OFF
  function mainOn() {
    const form = new ActionFormData()
      .title(titles.off)
      .body(`§a请选择操作...`)
      .button(`§e我的收集`, "textures/mobblocks/fish/items/custom_fish_3")
      .button(`§e打开高级钓鱼模式`, "textures/mobblocks/fish/items/custom_fish_2");

    form.show(player).then(r => {
      if (r.selection === 0) {
        showFishCollection(player);
      } else if (r.selection === 1) {
        toggleFishing(player, true);
        world.setDynamicProperty("fishingEnabled", true);
      }
    });
  }

  // Function to show main form when Advanced Fishing is ON
  function mainOff() {
    const form = new ActionFormData()
      .title(titles.on)
      .body(`\n§l§d${player.nameTag}\n\n§5Welcome to §gFishing§b+\n\n`)
      .button(`§rMy Collection`, "textures/mobblocks/fish/items/custom_fish_3")
      .button(`Turn §cOFF §rAdvanced Fishing`, "textures/mobblocks/fish/items/custom_fish_2");

    form.show(player).then(r => {
      if (r.selection === 0) {
        showFishCollection(player);
      } else if (r.selection === 1) {
        toggleFishing(player, false);
        world.setDynamicProperty("fishingEnabled", false);
      }
    });
  }

  // Function to toggle Advanced Fishing status
  function toggleFishing(player, isOn) {
    const scoreboard = world.scoreboard.getObjective("mbl_fish_settings");
    scoreboard?.setScore("fishing", isOn ? 1 : 0);
    world.sendMessage(`§4${player.nameTag} §fTurned Advanced Fishing ${isOn ? '§aON' : '§cOFF'}`);
  }

  // Function to show fish collection
  function showFishCollection(player) {
    const form = new ActionFormData()
      .title(titles.collection)
      .body(`§a已收集 §d${getScore('mbl_total_fish', player.nameTag)} §a不同的鱼！`)
      .button(`§e普通品质 ${getScore('mbl_total_fishc', player.nameTag)}/38`, "textures/mobblocks/fish/items/custom_fish_4")
      .button(`§e上品品质 ${getScore('mbl_total_fishu', player.nameTag)}/30`, "textures/mobblocks/fish/items/custom_fish_5")
      .button(`§e稀有品质 ${getScore('mbl_total_fishr', player.nameTag)}/12`, "textures/mobblocks/fish/items/custom_fish_6")
      .button(`§e返回`, "textures/mobblocks/fish/items/custom_fish_0");

    form.show(player).then(r => {
      if (r.selection === 0) showFishCategory(player, 'Common');
      if (r.selection === 1) showFishCategory(player, 'Uncommon');
      if (r.selection === 2) showFishCategory(player, 'Rare');
      if (r.selection === 3) mainOn(player);
    });
  }

  // Function to show fish category
  function showFishCategory(player, category) {
    const categoryTitle = titles[category.toLowerCase()];
    const fishOfCategory = fishData.filter(fish => fish.type === category);
    const form = new ActionFormData().title(categoryTitle).body(`§a已收集 §d${getScore(`mbl_total_fish${category[0].toLowerCase()}`, player.nameTag)} ${category} §a品质鱼！`);

    fishOfCategory.forEach(fish => {
      const displayName = getDynamicProperty(player, `mbl_${fish.id.split(':')[1]}`) ? fish.name : "§e未知品种";
      form.button(displayName, `${fish.image}`); // =============================================== image here ==========================================================
    });

    form.button(`§l§cBACK`, "textures/mobblocks/fish/items/custom_fish_0");
    form.show(player).then(r => {
      if (r.selection === fishOfCategory.length) showFishCollection(player);
      const selectedFish = fishOfCategory[r.selection];
      if (selectedFish) {
        const hasCaught = getDynamicProperty(player, `mbl_${selectedFish.id.split(':')[1]}`);
        if (hasCaught) {
          showFishDetails(player, selectedFish);
        } else {
          showUnknownFish(player, category);
        }
      }
    });
  }

  // Function to show fish details
  function showFishDetails(player, fish) {
    const form = createFishForm(
      `§l§u${fish.name} Details`,
      fish.cookable,
      fish.found,
      fish.details
    );
    form.show(player).then(r => {
      if (r.selection === 0) showFishCategory(player, fish.type);
    });
  }

  // Function to show unknown fish
  function showUnknownFish(player, category) {
    const form = new ActionFormData()
      .title("§l§d未知品种")
      .body(`§a无法找到关于这种鱼的信息，请捕捉一条再回来看！`)
      .button(`§e返回`, "textures/mobblocks/fish/items/custom_fish_0");

    form.show(player).then(r => {
      if (r.selection === 0) showFishCategory(player, category);
    });
  }
});

//========================== Code to update collection ==================================================================

function checkPlayerInventory(player) {
  const inventory = player.getComponent("minecraft:inventory").container;
  const itemsToCheck = {
"mbl_fish:alligator_gar": false,
"mbl_fish:anchovy": false,
"mbl_fish:arctic_char": false,
"mbl_fish:barracuda": false,
"mbl_fish:barramundi": false,
"mbl_fish:black_crappie": false,
"mbl_fish:blue_marlin": false,
"mbl_fish:bluefin_tuna": false,
"mbl_fish:bluegill": false,
"mbl_fish:bowfin": false,
"mbl_fish:bream": false,
"mbl_fish:brown_trout": false,
"mbl_fish:burbot": false,
"mbl_fish:channel_catfish": false,
"mbl_fish:chub": false,
"mbl_fish:cobia": false,
"mbl_fish:coelacanth": false,
"mbl_fish:common_carp": false,
"mbl_fish:common_molly": false,
"mbl_fish:croaker": false,
"mbl_fish:crucian_carp": false,
"mbl_fish:mahi_mahi": false,
"mbl_fish:eel": false,
"mbl_fish:escolar": false,
"mbl_fish:goby": false,
"mbl_fish:goldfish": false,
"mbl_fish:grass_carp": false,
"mbl_fish:grayling": false,
"mbl_fish:grouper": false,
"mbl_fish:gudgeon": false,
"mbl_fish:guppy": false,
"mbl_fish:haddock": false,
"mbl_fish:halibut": false,
"mbl_fish:herring": false,
"mbl_fish:large_mouth_bass": false,
"mbl_fish:lingcod": false,
"mbl_fish:lionfish": false,
"mbl_fish:mackerel": false,
"mbl_fish:milkfish": false,
"mbl_fish:minnow": false,
"mbl_fish:monkfish": false,
"mbl_fish:nile_perch": false,
"mbl_fish:northern_pike": false,
"mbl_fish:opah": false,
"mbl_fish:oscar": false,
"mbl_fish:patagonian_toothfish": false,
"mbl_fish:perch": false,
"mbl_fish:piranha": false,
"mbl_fish:pollock": false,
"mbl_fish:pompano": false,
"mbl_fish:pumkinseed": false,
"mbl_fish:rainbow_trout": false,
"mbl_fish:red_drum": false,
"mbl_fish:red_snapper": false,
"mbl_fish:roach": false,
"mbl_fish:roosterfish": false,
"mbl_fish:rudd": false,
"mbl_fish:sailfish": false,
"mbl_fish:sardine": false,
"mbl_fish:sea_bass": false,
"mbl_fish:skipjack_tuna": false,
"mbl_fish:snapper": false,
"mbl_fish:stickleback": false,
"mbl_fish:striped_bass": false,
"mbl_fish:sturgeon": false,
"mbl_fish:swordfish": false,
"mbl_fish:tarpon": false,
"mbl_fish:tench": false,
"mbl_fish:tilapia": false,
"mbl_fish:tilefish": false,
"mbl_fish:wahoo": false,
"mbl_fish:walleye": false,
"mbl_fish:white_bass": false,
"mbl_fish:whitefish": false,
"mbl_fish:yellowfin_tuna": false,
"mbl_fish:zander": false,
"minecraft:cod": false,
"minecraft:salmon": false,
"minecraft:pufferfish": false,
"minecraft:tropical_fish": false


  };

  if (inventory) { // Check if inventory exists
    for (let i = 0; i < inventory.size; i++) {
      const item = inventory.getItem(i);
      if (item && itemsToCheck.hasOwnProperty(item.typeId)) {
        itemsToCheck[item.typeId] = true;
      }
    }

  }

  return itemsToCheck;
}

// Event listener for player tick
system.runInterval(() => {
  for (const player of world.getPlayers()) {
    const playerName = player;
    const itemsFound = checkPlayerInventory(player);
    let message_common = "§e发现新的普通品质鱼！"
    let message_uncommon = "§e发现新的上品品质鱼！"
    let message_rare = "§e发现新的稀有品质鱼！"
    const mbl_fish_total_scoreboard = world.scoreboard.getObjective("mbl_total_fish"); // scoreboard
    const mbl_fish_totalC_scoreboard = world.scoreboard.getObjective("mbl_total_fishc"); // scoreboard
    const mbl_fish_totalUC_scoreboard = world.scoreboard.getObjective("mbl_total_fishu"); // scoreboard
    const mbl_fish_totalR_scoreboard = world.scoreboard.getObjective("mbl_total_fishr"); // scoreboard
    
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:anchovy"] && !player.getDynamicProperty("mbl_anchovy")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_anchovy", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:bluegill"] && !player.getDynamicProperty("mbl_bluegill")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_bluegill", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:brown_trout"] && !player.getDynamicProperty("mbl_brown_trout")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_brown_trout", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:burbot"] && !player.getDynamicProperty("mbl_burbot")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_burbot", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:channel_catfish"] && !player.getDynamicProperty("mbl_channel_catfish")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_channel_catfish", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:chub"] && !player.getDynamicProperty("mbl_chub")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_chub", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["minecraft:cod"] && !player.getDynamicProperty("mbl_cod")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_cod", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:common_carp"] && !player.getDynamicProperty("mbl_common_carp")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_common_carp", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:common_molly"] && !player.getDynamicProperty("mbl_common_molly")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_common_molly", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:crucian_carp"] && !player.getDynamicProperty("mbl_crucian_carp")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_crucian_carp", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:mahi_mahi"] && !player.getDynamicProperty("mbl_mahi_mahi")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_mahi_mahi", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:goby"] && !player.getDynamicProperty("mbl_goby")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_goby", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:goldfish"] && !player.getDynamicProperty("mbl_goldfish")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_goldfish", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:grayling"] && !player.getDynamicProperty("mbl_grayling")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_grayling", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:gudgeon"] && !player.getDynamicProperty("mbl_gudgeon")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_gudgeon", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:guppy"] && !player.getDynamicProperty("mbl_guppy")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_guppy", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:haddock"] && !player.getDynamicProperty("mbl_haddock")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_haddock", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:herring"] && !player.getDynamicProperty("mbl_herring")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_herring", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:large_mouth_bass"] && !player.getDynamicProperty("mbl_large_mouth_bass")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_large_mouth_bass", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:lingcod"] && !player.getDynamicProperty("mbl_lingcod")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_lingcod", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:mackerel"] && !player.getDynamicProperty("mbl_mackerel")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_mackerel", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:milkfish"] && !player.getDynamicProperty("mbl_milkfish")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_milkfish", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:minnow"] && !player.getDynamicProperty("mbl_minnow")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_minnow", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:northern_pike"] && !player.getDynamicProperty("mbl_northern_pike")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_northern_pike", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:perch"] && !player.getDynamicProperty("mbl_perch")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_perch", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:pollock"] && !player.getDynamicProperty("mbl_pollock")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_pollock", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:rainbow_trout"] && !player.getDynamicProperty("mbl_rainbow_trout")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_rainbow_trout", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:roach"] && !player.getDynamicProperty("mbl_roach")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_roach", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:rudd"] && !player.getDynamicProperty("mbl_rudd")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_rudd", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["minecraft:salmon"] && !player.getDynamicProperty("mbl_salmon")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_salmon", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:sardine"] && !player.getDynamicProperty("mbl_sardine")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_sardine", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:sea_bass"] && !player.getDynamicProperty("mbl_sea_bass")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_sea_bass", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:skipjack_tuna"] && !player.getDynamicProperty("mbl_skipjack_tuna")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_skipjack_tuna", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:stickleback"] && !player.getDynamicProperty("mbl_stickleback")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_stickleback", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:tench"] && !player.getDynamicProperty("mbl_tench")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_tench", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:tilapia"] && !player.getDynamicProperty("mbl_tilapia")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_tilapia", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:walleye"] && !player.getDynamicProperty("mbl_walleye")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_walleye", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:white_bass"] && !player.getDynamicProperty("mbl_white_bass")) {     player.sendMessage(message_common);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalC_scoreboard?.addScore(playerName, 1);     player.setDynamicProperty("mbl_white_bass", true); }// Set the dynamic property to avoid repeated messages

    if (checkPlayerInventory(player) && itemsFound["mbl_fish:arctic_char"] && !player.getDynamicProperty("mbl_arctic_char")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_arctic_char", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:barracuda"] && !player.getDynamicProperty("mbl_barracuda")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_barracuda", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:barramundi"] && !player.getDynamicProperty("mbl_barramundi")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_barramundi", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:black_crappie"] && !player.getDynamicProperty("mbl_black_crappie")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_black_crappie", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:bream"] && !player.getDynamicProperty("mbl_bream")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_bream", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:croaker"] && !player.getDynamicProperty("mbl_croaker")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_croaker", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:eel"] && !player.getDynamicProperty("mbl_eel")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_eel", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:escolar"] && !player.getDynamicProperty("mbl_escolar")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_escolar", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:grass_carp"] && !player.getDynamicProperty("mbl_grass_carp")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_grass_carp", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:grouper"] && !player.getDynamicProperty("mbl_grouper")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_grouper", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:halibut"] && !player.getDynamicProperty("mbl_halibut")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_halibut", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:lionfish"] && !player.getDynamicProperty("mbl_lionfish")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_lionfish", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:monkfish"] && !player.getDynamicProperty("mbl_monkfish")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_monkfish", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:nile_perch"] && !player.getDynamicProperty("mbl_nile_perch")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_nile_perch", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:oscar"] && !player.getDynamicProperty("mbl_oscar")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_oscar", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:piranha"] && !player.getDynamicProperty("mbl_piranha")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_piranha", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:pompano"] && !player.getDynamicProperty("mbl_pompano")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_pompano", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["minecraft:pufferfish"] && !player.getDynamicProperty("mbl_pufferfish")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_pufferfish", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:pumkinseed"] && !player.getDynamicProperty("mbl_pumkinseed")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_pumkinseed", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:red_drum"] && !player.getDynamicProperty("mbl_red_drum")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_red_drum", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:red_snapper"] && !player.getDynamicProperty("mbl_red_snapper")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_red_snapper", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:roosterfish"] && !player.getDynamicProperty("mbl_roosterfish")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_roosterfish", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:sailfish"] && !player.getDynamicProperty("mbl_sailfish")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_sailfish", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:snapper"] && !player.getDynamicProperty("mbl_snapper")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_snapper", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:striped_bass"] && !player.getDynamicProperty("mbl_striped_bass")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_striped_bass", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:tarpon"] && !player.getDynamicProperty("mbl_tarpon")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_tarpon", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:wahoo"] && !player.getDynamicProperty("mbl_wahoo")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_wahoo", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:whitefish"] && !player.getDynamicProperty("mbl_whitefish")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_whitefish", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:yellowfin_tuna"] && !player.getDynamicProperty("mbl_yellowfin_tuna")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_yellowfin_tuna", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:zander"] && !player.getDynamicProperty("mbl_zander")) {     player.sendMessage(message_uncommon);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalUC_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_zander", true); }// Set the dynamic property to avoid repeated messages

    if (checkPlayerInventory(player) && itemsFound["mbl_fish:alligator_gar"] && !player.getDynamicProperty("mbl_alligator_gar")) {     player.sendMessage(message_rare);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalR_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_alligator_gar", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:blue_marlin"] && !player.getDynamicProperty("mbl_blue_marlin")) {     player.sendMessage(message_rare);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalR_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_blue_marlin", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:bluefin_tuna"] && !player.getDynamicProperty("mbl_bluefin_tuna")) {     player.sendMessage(message_rare);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalR_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_bluefin_tuna", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:bowfin"] && !player.getDynamicProperty("mbl_bowfin")) {     player.sendMessage(message_rare);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalR_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_bowfin", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["minecraft:tropical_fish"] && !player.getDynamicProperty("mbl_tropical_fish")) {     player.sendMessage(message_rare);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalR_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_tropical_fish", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:cobia"] && !player.getDynamicProperty("mbl_cobia")) {     player.sendMessage(message_rare);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalR_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_cobia", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:coelacanth"] && !player.getDynamicProperty("mbl_coelacanth")) {     player.sendMessage(message_rare);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalR_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_coelacanth", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:opah"] && !player.getDynamicProperty("mbl_opah")) {     player.sendMessage(message_rare);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalR_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_opah", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:patagonian_toothfish"] && !player.getDynamicProperty("mbl_patagonian_toothfish")) {     player.sendMessage(message_rare);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalR_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_patagonian_toothfish", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:sturgeon"] && !player.getDynamicProperty("mbl_sturgeon")) {     player.sendMessage(message_rare);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalR_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_sturgeon", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:swordfish"] && !player.getDynamicProperty("mbl_swordfish")) {     player.sendMessage(message_rare);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalR_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_swordfish", true); }// Set the dynamic property to avoid repeated messages
    if (checkPlayerInventory(player) && itemsFound["mbl_fish:tilefish"] && !player.getDynamicProperty("mbl_tilefish")) {     player.sendMessage(message_rare);     mbl_fish_total_scoreboard?.addScore(playerName, 1);     mbl_fish_totalR_scoreboard?.addScore(playerName, 1);	player.setDynamicProperty("mbl_tilefish", true); }// Set the dynamic property to avoid repeated messages

  }
}, 40);
